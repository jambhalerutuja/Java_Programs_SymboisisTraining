package com.test.finalPractical.Service;

import java.util.List;


import com.test.finalPractical.Entities.Employee;

public interface EmployeeService {
	public List<Employee> getAllEmp();
	public Employee saveEmp(Employee emp);
	
	public Employee updateEmp(Employee emp);
	public Employee findById(long id);
	public void deleteEmp(long id);
	
	
}
