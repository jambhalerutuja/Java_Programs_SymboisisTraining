package com.test.finalPractical.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.test.finalPractical.Dao.EmployeeRepository;
import com.test.finalPractical.Entities.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

@Service
public class EmployeeServiceImp  implements EmployeeService{
	
		
	@Autowired
	private EmployeeRepository emprepo;
	
	@Autowired
	public EmployeeServiceImp(EmployeeRepository emprepo) {
		super();
		this.emprepo = emprepo;
	}

	@Override
	public List<Employee> getAllEmp() {
		List<Employee> findAll=	emprepo.findAll();	
		return findAll;
	}

	@Override
	public Employee saveEmp(Employee emp) {
		// TODO Auto-generated method stub
		return emprepo.save(emp) ;
	}

	@Override
	public Employee updateEmp(Employee emp) {
		// TODO Auto-generated method stub
		return emprepo.save(emp);
	}

	@Override
	public void deleteEmp(long id) {
		// TODO Auto-generated method stub
		emprepo.deleteById(id);
	}

	
	

	@Override
	public Employee findById(long id) {
		// TODO Auto-generated method stub
		Optional<Employee> findByid=emprepo.findById(id);
		Employee emp1=findByid.get();
		return emp1;
	}

	

}
	


