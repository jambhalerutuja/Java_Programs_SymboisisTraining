package com.test.finalPractical;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalPracticalApplicationTests {

	@Test
	void contextLoads() {
	}

}
